//import java.util.Arrays;

public class MatrixOperations {

    public static void main(String[] args) {
        int n = 3; // порядок матриць
        int[][][][] A = create4DMatrix(n);
        int[][][][] B = create4DMatrix(n);

        System.out.println("Матриця A:");
        print4DMatrix(A);
        System.out.println("Матриця B:");
        print4DMatrix(B);

        int[][][][] AT = transpose4DMatrix(A, new int[]{2, 1, 3, 4});

        System.out.println("Транспонована матриця A^T:");
        print4DMatrix(AT);

        int[][][][] D = convolute4DMatrices(A, B);

        System.out.println("Згорнутий добуток матриць A та B:");
        print4DMatrix(D);

        int[][][][] E = create4DIdentityMatrix(n);

        System.out.println("(λ,μ)-одинична матриця E:");
        print4DMatrix(E);

        int[][][][] F = multiply4DMatrices(E, B);

        System.out.println("Добуток матриць E та B:");
        print4DMatrix(F);
    }

    // Функція для створення 4-мірної матриці заданого порядку
    public static int[][][][] create4DMatrix(int n) {
        int[][][][] matrix = new int[n][n][n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    for (int l = 0; l < n; l++) {
                        matrix[i][j][k][l] = i + j + k + l; // можна змінити на будь-яке інше значення
                    }
                }
            }
        }
        return matrix;
    }

    // Функція для транспонування 4-мірної матриці відповідно до заданої підстановки
    public static int[][][][] transpose4DMatrix(int[][][][] matrix, int[] permutation) {
        // permutation-перестановка,indices-індекси
        int n = matrix.length;
        int[][][][] transposedMatrix = new int[n][n][n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    for (int l = 0; l < n; l++) {
                        int[] indices = {i, j, k, l};
                        int[] newIndices = new int[4];
                        for (int m = 0; m < 4; m++) {
                            newIndices[m] = indices[permutation[m] - 1];
                        }
                        transposedMatrix[newIndices[0]][newIndices[1]][newIndices[2]][newIndices[3]] = matrix[i][j][k][l];
                    }
                }
            }
        }
        return transposedMatrix;
    }

    // Функція для обчислення згорнутого добутку двох 4-мірних матриць
    public static int[][][][] convolute4DMatrices(int[][][][] A, int[][][][] B) {
        int n = A.length;
        int[][][][] result = new int[n][n][n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    for (int l = 0; l < n; l++) {
                        for (int m = 0; m < n; m++) {
                            for (int p = 0; p < n; p++) {
                                for (int q = 0; q < n; q++) {
                                    for (int r = 0; r < n; r++) {
                                        result[i][j][k][l] += A[i][j][m][p] * B[m][p][k][l];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

    // Функція для створення 4-мірної одиничної матриці заданого порядку
    public static int[][][][] create4DIdentityMatrix(int n) {
        int[][][][] matrix = new int[n][n][n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    for (int l = 0; l < n; l++) {
                        if (i == j && j == k && k == l) {
                            matrix[i][j][k][l] = 1;
                        }
                    }
                }
            }
        }
        return matrix;
    }
    // Функція для множення двох 4-мірних матриць
    public static int[][][][] multiply4DMatrices(int[][][][] A, int[][][][] B) {
        int n = A.length;
        int[][][][] result = new int[n][n][n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    for (int l = 0; l < n; l++) {
                        for (int m = 0; m < n; m++) {
                            for (int p = 0; p < n; p++) {
                                for (int q = 0; q < n; q++) {
                                    for (int r = 0; r < n; r++) {
                                        result[i][j][k][l] += A[i][j][m][p] * B[m][p][k][l];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

    // Функція для виведення 4-мірної матриці на екран
    public static void print4DMatrix(int[][][][] matrix) {
        for (int[][][] ints : matrix) {
            //System.out.println(" " + i + ":");
            for (int j = 0; j < matrix.length; j++) {
                for (int k = 0; k < matrix.length; k++) {
                    System.out.print("[");
                    for (int l = 0; l < matrix.length; l++) {
                        System.out.print(ints[j][k][l] + " ");
                    }
                    System.out.println("]");
                }
            }
            System.out.println();
        }
    }
}