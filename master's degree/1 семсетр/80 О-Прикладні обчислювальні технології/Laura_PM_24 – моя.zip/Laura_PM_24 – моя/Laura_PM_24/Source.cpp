﻿#include <iostream>
#include <cmath>

int main() {
	setlocale(LC_ALL, "Ukrainian");
	double table [8];
	char choice;
	std::cout << "Если вы хотите использовать свои значения введите 'y' если хотите использовать табличные введите 'n': ";
	std::cin >> choice;
	if (choice == 'y' || choice == 'Y')
	{
		std::string tabletxt[] = { "Щільність теплового потоку, Вт / м²: ","Товщина скла: ","Температура навколишнього середовища: ","Ступінь чорноти навколишнього середовища: ","Cтупінь чорноти скла: ","Ступінь чорноти елементу: ","Ступінь забруднення скла: ","Коефіцієнт теплопровідності скла: " };

		for (int n = 0; n < 8; n++) 
		{
			std::cout << tabletxt[n]; 
			std::cin >> table[n]; 

		}
		
		std::cout << table[0] << "\n";
		std::cout << table[1] << "\n";
		std::cout << table[2] << "\n";
		std::cout << table[3] << "\n";
		std::cout << table[4] << "\n";
		std::cout << table[5] << "\n";
		std::cout << table[6] << "\n";
		std::cout << table[7] << "\n";
	}
	else if (choice == 'n' || choice == 'N') 
	{
		table[0] = 600;
		table[1] = 0.003;
		table[2] = 20+273.15; 
		table[3] = 0.75;
		table[4] = 0.85;
		table[5] = 0.93;
		table[6] = 0.7;
		table[7] = 0.745;

	}
	else 
	{
		std::cout << "Некорректный выбор. Попробуйте снова.\n";
	}
	
	double Tel = 273.15, x, R;
	std::cout << "Введите температуру элемента: ";
	std::cin >> x;
	Tel = Tel + x; 
	double Epr1 = 1 / ((1 / table[3] + 1 / table[4]) - 1);
	double Epr3 = 1 / ((1 / table[5] + 1 / table[4]) - 1);
	double Tst, Alst, Alz, K, Tst1, Alst1, Alz1, K1;

	Tst = 100 * pow(0.5 * (pow(Tel / 100.0, 4) + pow(table[2] / 100.0, 4)), 0.25);
	Alst = 0.227 * Epr1 * pow((table[2] + Tst) / 200.0, 3);
	Alz = 0.227 * Epr3 * pow((Tst + Tel) / 200.0, 3);
	K = 1 / ((1 / Alst) + (1 / Alz) + (table[1] / table[7]));
	int iteration_count = 0;
	do {
		
		Tst1 = table[2] + (K * (Tel - table[2])) / Alst;
		Alst1 = 0.227 * Epr1 * pow((table[2] + Tst1) / 200.0, 3);
		Alz1 = 0.227 * Epr3 * pow((Tst1 + Tel) / 200.0, 3);
		K1 = 1 / ((1 / Alst1) + (1 / Alz1) + (table[1] / table[7]));
		R = ((K1 - K) / K1);

		K = K1;
		Tst = Tst1;
		Alst = Alst1;
		Alz = Alz1;
		iteration_count++;
	} while (R >= 0.05); 
	std::cout << "Значение достигнуто после " << iteration_count << " итераций." << std::endl;
	std::cout << "Разница между ((Кх-Кх-1)/Кx)= " << fabs(R);
}